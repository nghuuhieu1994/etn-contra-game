﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mario_Bros.Framework
{
    static public class GlobalSetting
    {
        public static bool IsExit = false;
        public static bool IsSoundEffect = true;
        public static bool IsSoundBG = true;
        public static int m_IDLevel = 0;
    }
}
